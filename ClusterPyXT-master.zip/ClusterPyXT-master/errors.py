from enum import IntEnum

class ClusterPyError(IntEnum):
    ciao_not_running = -1
    sources_or_exclude_not_found = 1
