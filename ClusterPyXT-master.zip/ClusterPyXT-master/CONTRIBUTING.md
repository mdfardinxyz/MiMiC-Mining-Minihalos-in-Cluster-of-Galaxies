# How to contribute
-
Whether or not you are familiar with python, x-ray astronomy, or even astronomy, you can help contribute. 

Feel free to email me if you are interested (even if you are a newbie!).

Brian
